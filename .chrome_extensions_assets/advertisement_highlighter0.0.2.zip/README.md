# Advertisement Highlighter

## Description
Highlight advertisements on a webpage.

## Package
MacOs has weird compression issues when making .zip files, so use the following command for uploading to Google:

    zip -r advertisement_highlighter.zip *
