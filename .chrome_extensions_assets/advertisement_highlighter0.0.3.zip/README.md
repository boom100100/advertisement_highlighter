# Advertisement Highlighter

## Description
Highlight advertisements on a webpage.

## Package
MacOs has weird compression issues when making .zip files, so use the following command for creating .zip to upload to Google:

    zip -r .chrome_extensions_assets/advertisement_highlighter0.0.v.zip *

Be sure to update the version number for the output.
